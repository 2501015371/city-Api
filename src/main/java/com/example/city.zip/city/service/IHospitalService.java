package com.example.city.service;

import com.example.city.entity.Hospital;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author astupidcoder
 * @since 2020-12-10
 */
public interface IHospitalService extends IService<Hospital> {

}
